"use client";

import { useState, useEffect } from "react";
import { useRouter } from "next/navigation";
import { format } from "date-fns";
import { v4 as uuidv4 } from "uuid";

// TYPE DEFINITIONS
export type Timeline = { s_no: number; description: string; deadline: string; status?: string; approved?: string };
export type CompletedProject = {
  id: string;
  completion_date: string;
  department: string;
  company_name: string;
  contact: string;
  state: string;
  deadline: string;
  description: string;
  fileName?: string;
  source: string;
  customer_notes: string;
  order_value: number;
  advance_payment: number;
  expense: number;
  profit: number;
  subdeal: string;
  project_handled_by: string;
  working_timeline: Timeline[];
  project_timeline: Timeline[];
  expense_bill_format?: string;
};

export default function CompletedProjectsListPage() {
  const router = useRouter();
  const [items, setItems] = useState<CompletedProject[]>([]);

  useEffect(() => {
    // This component assumes data is populated from another source (e.g., when a project is marked "Completed").
    // For testing, you might need to seed `localStorage` manually with the key "completedProjectsData".
    const storedData = localStorage.getItem("completedProjectsData");
    if (storedData) {
      const parsedData: CompletedProject[] = JSON.parse(storedData).map((item: any) => ({
        ...item,
        id: item.id || uuidv4(),
      }));
      setItems(parsedData);
    }
  }, []);

  const handleDelete = (id: string) => {
    if (confirm("Are you sure you want to delete this completed project?")) {
      const updatedItems = items.filter((item) => item.id !== id);
      setItems(updatedItems);
      localStorage.setItem("completedProjectsData", JSON.stringify(updatedItems));
    }
  };

  const formatCurrency = (value: number) => {
    return (value || 0).toLocaleString('en-IN', { style: 'currency', currency: 'INR' });
  };

  return (
    <div className="min-h-screen p-6 bg-white">
      <div className="flex items-center justify-between mb-4">
        <h1 className="text-2xl font-bold text-green-700">Completed Projects</h1>
      </div>

      <div className="overflow-x-auto border rounded shadow">
        <table className="w-full border-collapse">
          <thead className="text-green-800 bg-green-100">
            <tr>
              {[ "Completion Date", "Company", "Department", "Order Value", "Advance", "Expense", "Profit", "Actions" ].map((h) => (
                <th key={h} className="p-2 text-left border">{h}</th>
              ))}
            </tr>
          </thead>
          <tbody>
            {items.length > 0 ? (
              items.map((item) => (
                <tr key={item.id} className="border-b hover:bg-green-50">
                  <td className="p-2 border">{format(new Date(item.completion_date), "dd/MM/yyyy")}</td>
                  <td className="p-2 border">{item.company_name}</td>
                  <td className="p-2 border">{item.department}</td>
                  <td className="p-2 border">{formatCurrency(item.order_value)}</td>
                  <td className="p-2 border">{formatCurrency(item.advance_payment)}</td>
                  <td className="p-2 border">{formatCurrency(item.expense)}</td>
                  <td className="p-2 border font-semibold text-green-700">{formatCurrency(item.profit)}</td>
                  <td className="flex gap-2 p-2 border">
                    <button onClick={() => router.push(`/crm/pipelines/completed-projects/${item.id}/view`)} className="px-2 py-1 text-white bg-blue-500 rounded hover:bg-blue-600">View</button>
                    <button onClick={() => router.push(`/crm/pipelines/completed-projects/${item.id}/edit`)} className="px-2 py-1 text-white bg-yellow-500 rounded hover:bg-yellow-600">Update</button>
                    <button onClick={() => handleDelete(item.id)} className="px-2 py-1 text-white bg-red-500 rounded hover:bg-red-600">Delete</button>
                  </td>
                </tr>
              ))
            ) : (
              <tr>
                <td colSpan={8} className="p-4 text-center text-gray-500">
                  No completed projects found.
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
}