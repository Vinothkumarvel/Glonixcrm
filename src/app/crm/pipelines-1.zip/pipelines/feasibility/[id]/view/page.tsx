"use client";

import { useState, useEffect } from "react";
import { useRouter, useParams } from "next/navigation";
import { format } from "date-fns";
import type { Feasibility } from "../../page";

export default function ViewFeasibilityPage() {
  const router = useRouter();
  const params = useParams();
  const id = params.id as string;
  const [item, setItem] = useState<Feasibility | null>(null);

  useEffect(() => {
    if (id) {
      const storedData = localStorage.getItem("feasibilityData") || "[]";
      const data: Feasibility[] = JSON.parse(storedData);
      const itemToView = data.find((i) => i.id === id);
      if (itemToView) setItem(itemToView);
    }
  }, [id]);

  if (!item) return <div className="p-8">Item not found or loading...</div>;

  return (
    <div className="min-h-screen p-6 bg-gray-50">
      <div className="max-w-4xl p-8 mx-auto bg-white rounded-lg shadow-lg">
        <h1 className="mb-6 text-2xl font-bold text-green-700">Feasibility Details</h1>
        <div className="grid grid-cols-1 gap-x-8 gap-y-4 md:grid-cols-2">
          <DetailItem label="Date" value={format(new Date(item.date), "dd/MM/yyyy")} />
          <DetailItem label="Deadline" value={format(new Date(item.deadline), "dd/MM/yyyy")} />
          <DetailItem label="Department" value={item.department} />
          <DetailItem label="Source" value={item.source} />
          <DetailItem label="Company Name" value={item.company_name} />
          <DetailItem label="Contact" value={item.contact} />
          <DetailItem label="State" value={item.state} />
          <DetailItem label="Status" value={item.status} isStatus />
          <div className="md:col-span-2"><DetailItem label="File Name" value={item.fileName || "-"} /></div>
          <div className="md:col-span-2"><DetailItem label="Description" value={item.description} /></div>
          <div className="md:col-span-2"><DetailItem label="Customer Notes" value={item.customer_notes || "-"} /></div>
        </div>
        <div className="flex justify-end mt-8">
          <button onClick={() => router.push('/crm/pipelines/feasibility')} className="px-4 py-2 text-white bg-green-600 rounded hover:bg-green-700">Back to List</button>
        </div>
      </div>
    </div>
  );
}

const DetailItem = ({ label, value, isStatus }: { label: string; value: string; isStatus?: boolean }) => (
  <div>
    <h3 className="text-sm font-medium text-gray-500">{label}</h3>
    {isStatus ? (
      <span className={`mt-1 inline-block px-3 py-1 text-sm font-semibold text-white rounded-full ${
        value === "Approved" ? "bg-green-500"
      : value === "Rejected" ? "bg-red-500"
      : "bg-yellow-500"
      }`}>
        {value}
      </span>
    ) : (
      <p className="mt-1 text-lg text-gray-900">{value}</p>
    )}
  </div>
);