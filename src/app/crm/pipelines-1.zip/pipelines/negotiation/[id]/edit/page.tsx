"use client";

import { useState, useEffect } from "react";
import { useRouter, useParams } from "next/navigation";
import { Negotiation, teamMembers } from "../../page";

export default function EditNegotiationPage() {
  const router = useRouter();
  const params = useParams();
  const id = params.id as string;
  const [formData, setFormData] = useState<Negotiation | null>(null);

  useEffect(() => {
    if (id) {
      const storedData = localStorage.getItem("negotiationData") || "[]";
      const data: Negotiation[] = JSON.parse(storedData);
      const itemToEdit = data.find((item) => item.id === id);
      if (itemToEdit) setFormData(itemToEdit);
    }
  }, [id]);

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => {
    if (!formData) return;
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };
  
  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (!formData) return;
    const file = e.target.files?.[0];
    setFormData({ ...formData, fileName: file?.name || "" });
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData) return;

    const storedData = localStorage.getItem("negotiationData") || "[]";
    const data: Negotiation[] = JSON.parse(storedData);
    const updatedData = data.map((item) => (item.id === id ? formData : item));
    localStorage.setItem("negotiationData", JSON.stringify(updatedData));
    
    router.push("/crm/pipelines/negotiation");
  };

  if (!formData) return <div className="p-8">Loading...</div>;

  return (
    <div className="min-h-screen p-8 bg-white">
      <h1 className="mb-6 text-2xl font-bold text-green-700">Edit Negotiation</h1>
      <form onSubmit={handleSubmit} className="grid grid-cols-1 gap-6 p-6 rounded shadow md:grid-cols-2 bg-green-50">
        {/* Fields */}
        <div>
          <label className="block font-medium text-green-800">Company Name <span className="text-red-500">*</span></label>
          <input type="text" name="company_name" value={formData.company_name} onChange={handleChange} required className="w-full p-2 border rounded" />
        </div>
        <div>
          <label className="block font-medium text-green-800">Subdeal (Team Member) <span className="text-red-500">*</span></label>
          <input list="teamMembers" name="subdeal" value={formData.subdeal} onChange={handleChange} required className="w-full p-2 border rounded" />
          <datalist id="teamMembers">
            {teamMembers.map(m => <option key={m} value={m} />)}
          </datalist>
        </div>
        <div>
          <label className="block font-medium text-green-800">Deadline <span className="text-red-500">*</span></label>
          <input type="date" name="deadline" value={formData.deadline} onChange={handleChange} required className="w-full p-2 border rounded" />
        </div>
        <div>
          <label className="block font-medium text-green-800">File Upload</label>
          <input type="file" onChange={handleFileChange} className="w-full p-2 border rounded bg-white" />
           {formData.fileName && <p className="text-sm text-gray-500 mt-1">Current file: {formData.fileName}</p>}
        </div>
        <div className="md:col-span-2">
          <label className="block font-medium text-green-800">Customer Notes</label>
          <textarea name="customer_notes" value={formData.customer_notes} onChange={handleChange} rows={3} className="w-full p-2 border rounded"></textarea>
        </div>
        
        {/* Status and Conditional Fields */}
        <div className="p-4 border-t-2 border-green-200 md:col-span-2">
            <label className="block font-medium text-green-800">Quotation Status <span className="text-red-500">*</span></label>
            <select name="quotation_status" value={formData.quotation_status} onChange={handleChange} required className="w-full p-2 border rounded">
                <option value="Followup">Followup</option>
                <option value="Closed">Closed</option>
                <option value="Convert">Convert</option>
            </select>
        </div>

        {formData.quotation_status === "Followup" && (
            <div className="md:col-span-2">
                <label className="block font-medium text-green-800">Follow-up Date & Time</label>
                <input type="datetime-local" name="followup_datetime" value={formData.followup_datetime || ''} onChange={handleChange} className="w-full p-2 border rounded"/>
            </div>
        )}
         {formData.quotation_status === "Closed" && (
            <div className="md:col-span-2">
                <label className="block font-medium text-green-800">Reason for Closing</label>
                <textarea name="closed_reason" value={formData.closed_reason || ''} onChange={handleChange} rows={3} className="w-full p-2 border rounded"></textarea>
            </div>
        )}
         {formData.quotation_status === "Convert" && (
            <div className="md:col-span-2">
                <label className="block font-medium text-green-800">Mail Confirmation / PO Details</label>
                <textarea name="convert_info" value={formData.convert_info || ''} onChange={handleChange} rows={3} className="w-full p-2 border rounded"></textarea>
            </div>
        )}

        <div className="flex justify-end col-span-2 gap-4 mt-4">
          <button type="button" onClick={() => router.push('/crm/pipelines/negotiation')} className="px-4 py-2 border rounded bg-gray-200 hover:bg-gray-300">Cancel</button>
          <button type="submit" className="px-4 py-2 text-white bg-green-600 rounded hover:bg-green-700">Update</button>
        </div>
      </form>
    </div>
  );
}