"use client";

import { useState, useEffect } from "react";
import { useRouter } from "next/navigation";
import { format } from "date-fns";
import { v4 as uuidv4 } from "uuid";
import type { CompletedProject } from "../completed-projects/page";

export type Timeline = { s_no: number; description: string; deadline: string; status?: string; approved?: string };
export type PaymentPendingItem = {
  id: string;
  date: string;
  department: string;
  company_name: string;
  contact: string;
  state: string;
  deadline: string;
  description: string;
  order_value: number;
  advance_payment: number;
  expense: number;
  profit: number;
  balance_due: number;
  subdeal: string;
  project_handled_by: string;
  working_timeline: Timeline[];
  project_timeline: Timeline[];
  expense_bill_format?: string;
  status: "Pending" | "Paid" | "Overdue";
};

export default function PaymentPendingListPage() {
  const router = useRouter();
  const [items, setItems] = useState<PaymentPendingItem[]>([]);
  
  useEffect(() => {
    const storedData = localStorage.getItem("paymentPendingData") || "[]";
    if(storedData) setItems(JSON.parse(storedData));
  }, []);

  const updateLocalStorage = (updatedItems: PaymentPendingItem[]) => {
    localStorage.setItem("paymentPendingData", JSON.stringify(updatedItems));
  };

  const handleStatusChange = (id: string, status: PaymentPendingItem['status']) => {
    const itemToMove = items.find(item => item.id === id);
    if (!itemToMove) return;

    if (status === "Paid") {
      const newCompletedItem: CompletedProject = {
        ...itemToMove,
        completion_date: new Date().toISOString(),
      };
      
      const completedData = JSON.parse(localStorage.getItem("completedProjectsData") || "[]");
      completedData.push(newCompletedItem);
      localStorage.setItem("completedProjectsData", JSON.stringify(completedData));

      const updatedItems = items.filter(item => item.id !== id);
      setItems(updatedItems);
      updateLocalStorage(updatedItems);
      alert("Payment marked as Paid. Project moved to Completed.");

    } else {
      const updatedItems = items.map(item => (item.id === id ? { ...item, status } : item));
      setItems(updatedItems);
      updateLocalStorage(updatedItems);
    }
  };
  
  const handleDelete = (id: string) => {
    if (confirm("Are you sure you want to delete this item?")) {
        const updatedItems = items.filter(item => item.id !== id);
        setItems(updatedItems);
        updateLocalStorage(updatedItems);
    }
  };

  const formatCurrency = (value: number) => {
    return (value || 0).toLocaleString('en-IN', { style: 'currency', currency: 'INR' });
  };

  return (
    <div className="min-h-screen p-6 bg-white">
      <h1 className="text-2xl font-bold mb-4 text-green-700">Payment Pending</h1>
      <div className="overflow-x-auto border rounded shadow">
        <table className="w-full border-collapse">
          <thead className="text-green-800 bg-green-100 text-sm">
            <tr>
              {["Date", "Company", "Balance Due", "Status", "Actions"].map(h => <th key={h} className="p-2 text-left border">{h}</th>)}
            </tr>
          </thead>
          <tbody>
            {items.map(item => (
              <tr key={item.id} className="border-b hover:bg-green-50 text-sm">
                <td className="p-2 border">{format(new Date(item.date), "dd/MM/yyyy")}</td>
                <td className="p-2 border">{item.company_name}</td>
                <td className="p-2 border font-semibold">{formatCurrency(item.balance_due)}</td>
                <td className="p-2 border">
                  <select
                    value={item.status}
                    onChange={(e) => handleStatusChange(item.id, e.target.value as PaymentPendingItem['status'])}
                    className="p-1 border rounded"
                  >
                    <option value="Pending">Pending</option>
                    <option value="Paid">Paid</option>
                    <option value="Overdue">Overdue</option>
                  </select>
                </td>
                <td className="flex gap-2 p-2 border">
                   <button onClick={() => router.push(`/crm/pipelines/payment-pending/${item.id}/view`)} className="px-2 py-1 text-xs text-white bg-blue-500 rounded hover:bg-blue-600">View</button>
                   <button onClick={() => router.push(`/crm/pipelines/payment-pending/${item.id}/edit`)} className="px-2 py-1 text-xs text-white bg-yellow-500 rounded hover:bg-yellow-600">Update</button>
                   <button onClick={() => handleDelete(item.id)} className="px-2 py-1 text-xs text-white bg-red-500 rounded hover:bg-red-600">Delete</button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}