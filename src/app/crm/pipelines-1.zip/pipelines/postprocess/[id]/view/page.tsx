"use client";

import { useState, useEffect } from "react";
import { useRouter, useParams } from "next/navigation";
 import { format, isValid, parseISO } from "date-fns";
import type { PostProcessItem } from "../../page";

export default function ViewPostProcessPage() {
  const router = useRouter();
  const params = useParams();
  const id = params.id as string;
  const [item, setItem] = useState<PostProcessItem | null>(null);

  useEffect(() => {
    if (id) {
      const storedData = localStorage.getItem("postprocessData") || "[]";
      const data: PostProcessItem[] = JSON.parse(storedData);
      const itemToView = data.find((i) => i.id === id);
      if (itemToView) setItem(itemToView);
    }
  }, [id]);

  if (!item) return <div className="p-8">Item not found or loading...</div>;

  const formatCurrency = (value: number) => {
    return (value || 0).toLocaleString('en-IN', { style: 'currency', currency: 'INR' });
  }

  return (
    <div className="min-h-screen p-6 bg-gray-50">
      <div className="max-w-4xl p-8 mx-auto bg-white rounded-lg shadow-lg">
        <h1 className="mb-6 text-2xl font-bold text-green-700">Post Process Details</h1>
        
        <div className="mb-6">
            <h2 className="text-lg font-semibold text-green-800 border-b pb-2 mb-4">Project Information</h2>
            <div className="grid grid-cols-1 gap-x-8 gap-y-4 md:grid-cols-2">
                <DetailItem label="Date" value={format(new Date(item.date), "dd/MM/yyyy")} />
                

<DetailItem
  label="Expected Completion"
  value={
    item.deadline && isValid(new Date(item.deadline))
      ? format(new Date(item.deadline), "dd/MM/yyyy")
      : "—"
  }
/>

                <DetailItem label="Company Name" value={item.company_name} />
                <DetailItem label="Project Handled By" value={item.project_handled_by} />
            </div>
        </div>

         <div className="mb-6">
             <h2 className="text-lg font-semibold text-green-800 border-b pb-2 mb-4">Financial Summary</h2>
             <div className="grid grid-cols-1 gap-x-8 gap-y-4 md:grid-cols-2">
                <DetailItem label="Order Value" value={formatCurrency(item.order_value)} />
                <DetailItem label="Balance Due" value={formatCurrency(item.balance_due)} />
                <div className="md:col-span-2 p-3 bg-green-50 rounded-lg">
                    <DetailItem label="Calculated Profit" value={formatCurrency(item.profit)} />
                </div>
            </div>
        </div>

        <div className="mb-6">
            <h2 className="text-lg font-semibold text-green-800 border-b pb-2 mb-4">Working Timeline</h2>
            <div className="space-y-3">
                {item.working_timeline.length > 0 ? item.working_timeline.map((t, i) => (
                    <div key={i} className="p-3 border rounded-md bg-gray-50">
                        <p className="font-semibold">{t.s_no}. {t.description}</p>
                        <div className="flex justify-between items-center mt-1 text-sm">
                           

<p className="text-gray-600">
  Deadline:{" "}
  {t.deadline && isValid(new Date(t.deadline))
    ? format(new Date(t.deadline), "dd MMMM, yyyy")
    : "—"}
</p>

                            <span className={`px-2 py-0.5 rounded-full text-xs font-medium ${
                                t.status === "Completed" ? "bg-green-100 text-green-800" : "bg-red-100 text-red-800"
                            }`}>{t.status}</span>
                        </div>
                    </div>
                )) : <p className="text-gray-500">No working timeline entries.</p>}
            </div>
        </div>
        
        <div className="flex justify-end mt-8">
          <button onClick={() => router.push('/crm/pipelines/postprocess')} className="px-4 py-2 text-white bg-green-600 rounded hover:bg-green-700">Back to List</button>
        </div>
      </div>
    </div>
  );
}

const DetailItem = ({ label, value }: { label: string; value: string }) => (
    <div>
        <h3 className="text-sm font-medium text-gray-500">{label}</h3>
        <p className="mt-1 text-lg text-gray-900">{value}</p>
    </div>
);