"use client";

import { useState, useEffect } from "react";
import { useRouter } from "next/navigation";
import { format } from "date-fns";
import { v4 as uuidv4 } from "uuid";

// TYPE DEFINITIONS
export type WorkingTimeline = {
  s_no: number;
  description: string;
  deadline: string;
  status: "Completed" | "Over Due"; // <-- ADD THIS LINE
  approved: "Yes" | "Rework";      // <-- ADD THIS LINE
};
export type PreprocessItem = {
  id: string;
  date: string;
  department: string;
  company_name: string;
  contact: string;
  state: string;
  deadline: string;
  description: string;
  fileName?: string;
  source: string;
  customer_notes: string;
  order_value: number;
  advance_payment: number;
  expense: number;
  profit: number;
  balance_due: number;
  subdeal: string;
  project_handled_by: string;
  working_timeline: WorkingTimeline[];
  project_timeline: WorkingTimeline[];
  expense_bill_format: string;
  approval_status: "Modification" | "Approved";
};

// SHARED CONSTANTS
export const departments = ["Fab", "EMS", "Component", "R&D"];
export const teamMembers = ["Alice", "Bob", "Charlie", "David", "Eve"];
export const expenseOptions = ["Format 1", "Format 2", "Format 3", "Format 4", "Format 5"];

export default function PreprocessListPage() {
  const router = useRouter();
  const [items, setItems] = useState<PreprocessItem[]>([]);

  useEffect(() => {
    const storedData = localStorage.getItem("preprocessData");
    if (storedData) {
      const parsedData: PreprocessItem[] = JSON.parse(storedData).map((item: any) => ({
        ...item,
        id: item.id || uuidv4(),
      }));
      setItems(parsedData);
    }
  }, []);

  const handleDelete = (id: string) => {
    if (confirm("Are you sure you want to delete this item?")) {
      const updatedItems = items.filter((item) => item.id !== id);
      setItems(updatedItems);
      localStorage.setItem("preprocessData", JSON.stringify(updatedItems));
    }
  };

  const formatCurrency = (value: number) => {
    return (value || 0).toLocaleString('en-IN', { style: 'currency', currency: 'INR' });
  }

  return (
    <div className="min-h-screen p-6 bg-white">
      <div className="flex items-center justify-between mb-4">
        <h1 className="text-2xl font-bold text-green-700">Preprocess</h1>
        <button
          onClick={() => router.push("/crm/pipelines/preprocess/new")}
          className="px-4 py-2 text-white bg-green-600 rounded hover:bg-green-700"
        >
          + Add Preprocess
        </button>
      </div>

      <div className="overflow-x-auto border rounded shadow">
        <table className="w-full border-collapse">
          <thead className="text-green-800 bg-green-100">
            <tr>
              {[ "Date", "Company Name", "Order Value", "Profit", "Handled By", "Status", "Actions" ].map((h) => (
                <th key={h} className="p-2 text-left border">{h}</th>
              ))}
            </tr>
          </thead>
          <tbody>
            {items.length > 0 ? (
              items.map((item) => (
                <tr key={item.id} className="border-b hover:bg-green-50">
                  <td className="p-2 border">{format(new Date(item.date), "dd/MM/yyyy")}</td>
                  <td className="p-2 border">{item.company_name}</td>
                  <td className="p-2 border">{formatCurrency(item.order_value)}</td>
                  <td className="p-2 border font-semibold text-green-700">{formatCurrency(item.profit)}</td>
                  <td className="p-2 border">{item.project_handled_by}</td>
                  <td className="p-2 border">
                     <span className={`px-2 py-1 text-xs font-semibold rounded-full ${
                        item.approval_status === "Approved" ? "bg-green-100 text-green-800" : "bg-yellow-100 text-yellow-800"
                     }`}>
                        {item.approval_status}
                     </span>
                  </td>
                  <td className="flex gap-2 p-2 border">
                    <button onClick={() => router.push(`/crm/pipelines/preprocess/${item.id}/view`)} className="px-2 py-1 text-white bg-blue-500 rounded hover:bg-blue-600">View</button>
                    <button onClick={() => router.push(`/crm/pipelines/preprocess/${item.id}/edit`)} className="px-2 py-1 text-white bg-yellow-500 rounded hover:bg-yellow-600">Edit</button>
                    <button onClick={() => handleDelete(item.id)} className="px-2 py-1 text-white bg-red-500 rounded hover:bg-red-600">Delete</button>
                  </td>
                </tr>
              ))
            ) : (
              <tr>
                <td colSpan={7} className="p-4 text-center text-gray-500">
                  No preprocess items found.
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
}