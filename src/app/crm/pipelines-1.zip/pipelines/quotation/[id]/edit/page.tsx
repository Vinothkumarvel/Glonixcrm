"use client";

import { useState, useEffect } from "react";
import { useRouter, useParams } from "next/navigation";
import type { Quotation } from "../../page";

export default function EditQuotationPage() {
  const router = useRouter();
  const params = useParams();
  const id = params.id as string;
  const [formData, setFormData] = useState<Quotation | null>(null);

  useEffect(() => {
    if (id) {
      const storedData = localStorage.getItem("quotationData") || "[]";
      const data: Quotation[] = JSON.parse(storedData);
      const itemToEdit = data.find((item) => item.id === id);
      if (itemToEdit) setFormData(itemToEdit);
    }
  }, [id]);

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => {
    if (!formData) return;
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };
  
  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (!formData) return;
    const file = e.target.files?.[0];
    setFormData({ ...formData, fileName: file?.name || "" });
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData) return;

    const storedData = localStorage.getItem("quotationData") || "[]";
    const data: Quotation[] = JSON.parse(storedData);
    const updatedData = data.map((item) => (item.id === id ? formData : item));
    localStorage.setItem("quotationData", JSON.stringify(updatedData));
    
    router.push("/crm/pipelines/quotation");
  };

  if (!formData) return <div className="p-8">Loading...</div>;

  return (
    <div className="min-h-screen p-8 bg-white">
      <h1 className="mb-6 text-2xl font-bold text-green-700">Edit Quotation</h1>
      {/* Form is identical to the 'New' page form */}
      <form onSubmit={handleSubmit} className="grid grid-cols-1 gap-6 p-6 rounded shadow md:grid-cols-2 bg-green-50">
        <div>
          <label className="block font-medium text-green-800">Department <span className="text-red-500">*</span></label>
          <input list="departments" name="department" value={formData.department} onChange={handleChange} required className="w-full p-2 border rounded" />
          <datalist id="departments">
            <option value="Fab" /> <option value="EMS" /> <option value="Component" /> <option value="R&D" />
          </datalist>
        </div>
        <div>
          <label className="block font-medium text-green-800">Company Name <span className="text-red-500">*</span></label>
          <input type="text" name="company_name" value={formData.company_name} onChange={handleChange} required className="w-full p-2 border rounded" />
        </div>
        <div>
          <label className="block font-medium text-green-800">Contact <span className="text-red-500">*</span></label>
          <input type="text" name="contact" value={formData.contact} onChange={handleChange} required className="w-full p-2 border rounded" />
        </div>
        <div>
          <label className="block font-medium text-green-800">State <span className="text-red-500">*</span></label>
          <input type="text" name="state" value={formData.state} onChange={handleChange} required className="w-full p-2 border rounded" />
        </div>
        <div>
          <label className="block font-medium text-green-800">Deadline <span className="text-red-500">*</span></label>
          <input type="date" name="deadline" value={formData.deadline} onChange={handleChange} required className="w-full p-2 border rounded" />
        </div>
        <div>
          <label className="block font-medium text-green-800">Source</label>
          <input type="text" name="source" value={formData.source} onChange={handleChange} className="w-full p-2 border rounded" />
        </div>
        <div className="md:col-span-2">
          <label className="block font-medium text-green-800">Description</label>
          <textarea name="description" value={formData.description} onChange={handleChange} rows={3} className="w-full p-2 border rounded"></textarea>
        </div>
        <div className="md:col-span-2">
          <label className="block font-medium text-green-800">Customer Notes</label>
          <textarea name="customer_notes" value={formData.customer_notes} onChange={handleChange} rows={2} className="w-full p-2 border rounded"></textarea>
        </div>
        <div>
          <label className="block font-medium text-green-800">File Upload</label>
          <input type="file" onChange={handleFileChange} className="w-full p-2 border rounded bg-white" />
          {formData.fileName && <p className="text-sm text-gray-500 mt-1">Current file: {formData.fileName}</p>}
        </div>
        <div className="flex justify-end col-span-2 gap-4 mt-4">
          <button type="button" onClick={() => router.push('/crm/pipelines/quotation')} className="px-4 py-2 border rounded bg-gray-200 hover:bg-gray-300">Cancel</button>
          <button type="submit" className="px-4 py-2 text-white bg-green-600 rounded hover:bg-green-700">Update</button>
        </div>
      </form>
    </div>
  );
}