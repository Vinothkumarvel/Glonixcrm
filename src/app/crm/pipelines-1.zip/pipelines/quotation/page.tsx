"use client";

import { useState, useEffect } from "react";
import { useRouter } from "next/navigation";
import { format } from "date-fns";
import { v4 as uuidv4 } from "uuid";

// TYPE DEFINITION IS CO-LOCATED HERE
export type Quotation = {
  id: string;
  date: string;
  department: string;
  company_name: string;
  contact: string;
  state: string;
  deadline: string;
  description: string;
  fileName?: string;
  source: string;
  customer_notes: string;
  status: "Pending" | "Followup" | "Closed" | "Convert";
};

export default function QuotationListPage() {
  const router = useRouter();
  const [items, setItems] = useState<Quotation[]>([]);

  useEffect(() => {
    const storedData = localStorage.getItem("quotationData");
    if (storedData) {
      const parsedData: Quotation[] = JSON.parse(storedData).map((item: any) => ({
        ...item,
        id: item.id || uuidv4(),
      }));
      setItems(parsedData);
    }
  }, []);

  const updateLocalStorage = (updatedItems: Quotation[]) => {
    localStorage.setItem("quotationData", JSON.stringify(updatedItems));
  };

  const handleDelete = (id: string) => {
    if (confirm("Are you sure you want to delete this quotation?")) {
      const updatedItems = items.filter((item) => item.id !== id);
      setItems(updatedItems);
      updateLocalStorage(updatedItems);
    }
  };

  const handleStatusChange = (id: string, status: Quotation["status"]) => {
    const updatedItems = items.map((item) =>
      item.id === id ? { ...item, status } : item
    );
    setItems(updatedItems);
    updateLocalStorage(updatedItems);
  };

  return (
    <div className="min-h-screen p-6 bg-white">
      <div className="flex items-center justify-between mb-4">
        <h1 className="text-2xl font-bold text-green-700">Quotation Preparation</h1>
        <button
          onClick={() => router.push("/crm/pipelines/quotation/new")}
          className="px-4 py-2 text-white bg-green-600 rounded hover:bg-green-700"
        >
          + Add Quotation
        </button>
      </div>

      <div className="overflow-x-auto border rounded shadow">
        <table className="w-full border-collapse">
          <thead className="text-green-800 bg-green-100">
            <tr>
              {[ "Date", "Department", "Company Name", "Deadline", "Status", "Actions" ].map((h) => (
                <th key={h} className="p-2 text-left border">{h}</th>
              ))}
            </tr>
          </thead>
          <tbody>
            {items.length > 0 ? (
              items.map((item) => (
                <tr key={item.id} className="border-b hover:bg-green-50">
                  <td className="p-2 border">{format(new Date(item.date), "dd/MM/yyyy")}</td>
                  <td className="p-2 border">{item.department}</td>
                  <td className="p-2 border">{item.company_name}</td>
                  <td className="p-2 border">{format(new Date(item.deadline), "dd/MM/yyyy")}</td>
                  <td className="p-2 border">
                    <select
                      value={item.status}
                      onChange={(e) => handleStatusChange(item.id, e.target.value as Quotation["status"])}
                      className="w-full p-1 text-sm border rounded"
                    >
                      <option value="Pending">Pending</option>
                      <option value="Followup">Followup</option>
                      <option value="Closed">Closed</option>
                      <option value="Convert">Convert</option>
                    </select>
                  </td>
                  <td className="flex gap-2 p-2 border">
                    <button onClick={() => router.push(`/crm/pipelines/quotation/${item.id}/view`)} className="px-2 py-1 text-white bg-blue-500 rounded hover:bg-blue-600">View</button>
                    <button onClick={() => router.push(`/crm/pipelines/quotation/${item.id}/edit`)} className="px-2 py-1 text-white bg-yellow-500 rounded hover:bg-yellow-600">Edit</button>
                    <button onClick={() => handleDelete(item.id)} className="px-2 py-1 text-white bg-red-500 rounded hover:bg-red-600">Delete</button>
                  </td>
                </tr>
              ))
            ) : (
              <tr>
                <td colSpan={6} className="p-4 text-center text-gray-500">
                  No quotations found.
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
}