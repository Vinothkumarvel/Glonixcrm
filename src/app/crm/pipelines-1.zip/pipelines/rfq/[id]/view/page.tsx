"use client";

import { useState, useEffect } from "react";
import { useRouter, useParams } from "next/navigation";
import { format } from "date-fns";
import type { RFQ } from "../../page"; // Import type from the main page

export default function ViewRFQPage() {
  const router = useRouter();
  const params = useParams();
  const id = params.id as string;
  const [rfq, setRfq] = useState<RFQ | null>(null);

  useEffect(() => {
    if (id) {
      const storedData = localStorage.getItem("rfqData") || "[]";
      const data: RFQ[] = JSON.parse(storedData);
      const rfqToView = data.find((r) => r.id === id);
      if (rfqToView) {
        setRfq(rfqToView);
      }
    }
  }, [id]);

  if (!rfq) {
    return <div className="p-8">RFQ not found or loading...</div>;
  }

  return (
    <div className="min-h-screen p-6 bg-gray-50">
      <div className="max-w-4xl p-8 mx-auto bg-white rounded-lg shadow-lg">
        <h1 className="mb-6 text-2xl font-bold text-green-700">RFQ Details</h1>
        <div className="grid grid-cols-1 gap-x-8 gap-y-4 md:grid-cols-2">
            <DetailItem label="Date" value={format(new Date(rfq.date), "dd/MM/yyyy")} />
            <DetailItem label="Deadline" value={format(new Date(rfq.deadline), "dd/MM/yyyy")} />
            <DetailItem label="Department" value={rfq.department} />
            <DetailItem label="Source" value={rfq.source} />
            <DetailItem label="Company Name" value={rfq.company_name} />
            <DetailItem label="Contact" value={rfq.contact} />
            <DetailItem label="State" value={rfq.state} />
            <DetailItem label="Status" value={rfq.status} isStatus />
            <div className="md:col-span-2">
                <DetailItem label="File Name" value={rfq.fileName || "-"} />
            </div>
            <div className="md:col-span-2">
                <DetailItem label="Description" value={rfq.description} />
            </div>
        </div>
        <div className="flex justify-end mt-8">
          <button onClick={() => router.push("/crm/pipelines/rfq")} className="px-4 py-2 text-white bg-green-600 rounded hover:bg-green-700">Back to List</button>
        </div>
      </div>
    </div>
  );
}

// Helper component for displaying details
const DetailItem = ({ label, value, isStatus }: { label: string; value: string; isStatus?: boolean }) => (
    <div>
        <h3 className="text-sm font-medium text-gray-500">{label}</h3>
        {isStatus ? (
             <span className={`mt-1 px-3 py-1 text-sm font-semibold text-white rounded-full ${
                value === "Pending" ? "bg-yellow-500"
              : value === "In Progress" ? "bg-blue-500"
              : "bg-green-500"
            }`}>
              {value}
            </span>
        ) : (
            <p className="mt-1 text-lg text-gray-900">{value}</p>
        )}
    </div>
);