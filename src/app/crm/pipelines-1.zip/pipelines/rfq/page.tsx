"use client";

import { useState, useEffect } from "react";
import { useRouter } from "next/navigation";
import { format } from "date-fns";
import { v4 as uuidv4 } from "uuid";

// TYPE DEFINITION IS NOW HERE
export type RFQ = {
  id: string;
  date: string;
  department: string;
  company_name: string;
  contact: string;
  state: string;
  deadline: string;
  description: string;
  fileName?: string;
  source: string;
  status: "Pending" | "In Progress" | "Completed";
};

export default function RFQListPage() {
  const router = useRouter();
  const [rfqs, setRfqs] = useState<RFQ[]>([]);

  useEffect(() => {
    const storedData = localStorage.getItem("rfqData");
    if (storedData) {
      const parsedData: RFQ[] = JSON.parse(storedData).map((item: any) => ({
        ...item,
        id: item.id || uuidv4(),
      }));
      setRfqs(parsedData);
    }
  }, []);

  const handleDelete = (id: string) => {
    if (confirm("Are you sure you want to delete this RFQ?")) {
      const updatedRfqs = rfqs.filter((r) => r.id !== id);
      setRfqs(updatedRfqs);
      localStorage.setItem("rfqData", JSON.stringify(updatedRfqs));
    }
  };

  return (
    <div className="min-h-screen p-6 bg-white">
      <div className="flex items-center justify-between mb-4">
        <h1 className="text-2xl font-bold text-green-700">RFQ (Request for Quotation)</h1>
        <button
          onClick={() => router.push("/crm/pipelines/rfq/new")}
          className="px-4 py-2 text-white bg-green-600 rounded hover:bg-green-700"
        >
          + Add RFQ
        </button>
      </div>

      <div className="overflow-x-auto border rounded shadow">
        <table className="w-full border-collapse">
          <thead className="text-green-800 bg-green-100">
            <tr>
              {[ "Date", "Department", "Company Name", "Deadline", "Source", "Status", "Action" ].map((header) => (
                <th key={header} className="p-2 text-left border">{header}</th>
              ))}
            </tr>
          </thead>
          <tbody>
            {rfqs.length > 0 ? (
              rfqs.map((rfq) => (
                <tr key={rfq.id} className="border-b hover:bg-green-50">
                  <td className="p-2 border">{format(new Date(rfq.date), "dd/MM/yyyy")}</td>
                  <td className="p-2 border">{rfq.department}</td>
                  <td className="p-2 border">{rfq.company_name}</td>
                  <td className="p-2 border">{format(new Date(rfq.deadline), "dd/MM/yyyy")}</td>
                  <td className="p-2 border">{rfq.source}</td>
                  <td className="p-2 border">
                    <span className={`px-2 py-1 text-xs font-semibold text-white rounded-full ${
                        rfq.status === "Pending" ? "bg-yellow-500"
                      : rfq.status === "In Progress" ? "bg-blue-500"
                      : "bg-green-500"
                    }`}>
                      {rfq.status}
                    </span>
                  </td>
                  <td className="flex gap-2 p-2 border">
                    <button onClick={() => router.push(`/crm/pipelines/rfq/${rfq.id}/view`)} className="px-2 py-1 text-white bg-blue-500 rounded hover:bg-blue-600">View</button>
                    <button onClick={() => router.push(`/crm/pipelines/rfq/${rfq.id}/edit`)} className="px-2 py-1 text-white bg-yellow-500 rounded hover:bg-yellow-600">Edit</button>
                    <button onClick={() => handleDelete(rfq.id)} className="px-2 py-1 text-white bg-red-500 rounded hover:bg-red-600">Delete</button>
                  </td>
                </tr>
              ))
            ) : (
              <tr>
                <td colSpan={7} className="p-4 text-center text-gray-500">
                  No RFQs found. Click "+ Add RFQ" to create one.
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
}